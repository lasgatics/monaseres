<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar3');
class TableStatsWholePathVar3 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 3;
    }
}
