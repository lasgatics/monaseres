<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar5');
class TableStatsWholePathVar5 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 5;
    }
}
