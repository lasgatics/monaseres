<?php

namespace ClickerVolt;

class ClickbankIPN
{ 
    
}
